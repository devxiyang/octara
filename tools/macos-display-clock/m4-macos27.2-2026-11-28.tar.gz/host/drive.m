#import <AppKit/AppKit.h>
#import <Metal/Metal.h>
#import <QuartzCore/QuartzCore.h>
#import <objc/runtime.h>

static id<CAMetalDrawable> (*originalNextDrawable)(CAMetalLayer *, SEL);

static id<CAMetalDrawable> nextDrawable(CAMetalLayer *layer, SEL selector) {
    id<CAMetalDrawable> drawable = originalNextDrawable(layer, selector);
    [drawable addPresentedHandler:^(id<MTLDrawable> presented) {
        fprintf(stderr, "clock-host,present,%.9f\n", presented.presentedTime);
    }];
    return drawable;
}

static void moveWindow(NSWindow *window, NSScreen *screen, const char *stage) {
    NSRect frame = window.frame;
    frame.origin = NSMakePoint(NSMidX(screen.visibleFrame) - frame.size.width / 2,
                               NSMidY(screen.visibleFrame) - frame.size.height / 2);
    [window setFrame:frame display:YES animate:NO];
    fprintf(stderr, "clock-host,stage,%s,%.9f,%ld,%s\n",
            stage, CACurrentMediaTime(), (long)window.screen.maximumFramesPerSecond,
            window.screen.localizedName.UTF8String);
}

static void awaitWindow(void) {
    for (NSWindow *window in NSApp.windows) {
        if (!window.isVisible || ![window.title isEqualToString:@"Octara frame clock integration"]) {
            continue;
        }
        NSScreen *internal = nil;
        NSScreen *external = nil;
        for (NSScreen *screen in NSScreen.screens) {
            NSNumber *identifier = screen.deviceDescription[@"NSScreenNumber"];
            if (CGDisplayIsBuiltin(identifier.unsignedIntValue)) {
                internal = screen;
            } else if (!external || screen.maximumFramesPerSecond > external.maximumFramesPerSecond) {
                external = screen;
            }
        }
        if (!internal || !external) {
            exit(2);
        }
        moveWindow(window, internal, "internal");
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 4 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
            moveWindow(window, external, "external");
        });
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 8 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
            moveWindow(window, internal, "returned");
        });
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 17 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
            [NSApp terminate:nil];
        });
        return;
    }
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 50 * NSEC_PER_MSEC), dispatch_get_main_queue(), ^{
        awaitWindow();
    });
}

__attribute__((constructor)) static void install(void) {
    Method method = class_getInstanceMethod(CAMetalLayer.class, @selector(nextDrawable));
    originalNextDrawable = (void *)method_setImplementation(method, (IMP)nextDrawable);
    dispatch_async(dispatch_get_main_queue(), ^{ awaitWindow(); });
}
