from collections import Counter
from pathlib import Path
import json
import re
import statistics
import sys

regions = []
presents = []
ticks = None
records = re.findall(
    r'clock-host,stage,[^\n]+|clock-host,present,[0-9.]+|\{"event":"display_tick",[^\n]+?\}\}',
    Path(sys.argv[1]).read_text(),
)
for line in records:
    if line.startswith("clock-host,stage,"):
        _, _, name, time, rate, screen = line.split(",", 5)
        ticks = []
        regions.append((name, float(time), int(rate), screen, ticks))
    elif line.startswith("clock-host,present,"):
        presents.append(float(line.rsplit(",", 1)[-1]))
    elif ticks is not None and line.startswith('{"event":"display_tick",'):
        ticks.append(json.loads(line))

print("stage / screen / panel Hz / ticks / target span Hz / common frame interval ms / receives / present Hz / median present gap ms")
for name, start, rate, screen, ticks in regions:
    # Skip the animation-start and screen-move transitions.
    if not ticks:
        continue
    target_start = ticks[0]["target_ns"]
    settled = [t for t in ticks if target_start + 900_000_000 < t["target_ns"] < target_start + 3_600_000_000]
    times = [t["target_ns"] / 1_000_000_000 for t in settled]
    presented = sorted(t for t in presents if start + 1.0 < t < start + 3.8)
    gap = statistics.median(b - a for a, b in zip(presented, presented[1:])) * 1_000
    tick_hz = (len(times)-1)/(times[-1]-times[0])
    present_hz = (len(presented)-1)/(presented[-1]-presented[0])
    interval = Counter(round(t["interval_ns"] / 1_000_000, 3) for t in settled).most_common(1)[0][0]
    print(f"{name} / {screen} / {rate} / {len(settled)} / {tick_hz:.2f} / {interval} / {len(presented)} / {present_hz:.2f} / {gap:.3f}")
print(f"zero presented reports in whole run: {presents.count(0)}")
