use octara::prelude::*;
use octara_examples::window_options;
use octara_examples_desktop::native;
use std::time::Duration;

#[ui]
fn fixture(build: &mut BuildCx<'_>) -> El {
    let hot = build.signal(false);
    build.spawn("start a color transition", move |task| async move {
        task.sleep(Duration::from_millis(500)).await;
        task.write(|writer| writer.set(hot, true));
    });
    el().size(rel(1.0))
        .style(StyleProp::ColorMotion(Curve::Fade(14.0)))
        .bg(move |reader: &mut ReadCx<'_>| if reader.get(hot) { rgb(0xdb5c63) } else { rgb(0x2455d0) })
}
fn main() {
    native::run(window_options("Octara frame clock integration", 480.0, 320.0), fixture).unwrap();
}
